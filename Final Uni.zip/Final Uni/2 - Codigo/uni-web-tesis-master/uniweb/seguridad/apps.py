from django.apps import AppConfig


class SeguridadConfig(AppConfig):
    name = 'seguridad'
